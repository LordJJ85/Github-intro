//Christie Jones
//CIS 1202 201
//10-08-2020

#include <iostream>
#include <iomanip>
#include <ctime>
#include <cstdlib>
#include <string>
#include<cstring>
#include <sstream>

using namespace std;

enum suits { HEARTS, DIAMONDS, SPADES, CLUBS };
enum ranks { TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE };

struct Cards {
public:
    suits suit;
    ranks rank;

};
suits face;
ranks numb;

/*void printDeck(cards[]);
{


}*/

int main()
{

    const int NUM_FAC = 4;
    int suit[NUM_FAC];
    int Count;
    char var;
    int deck;
    int random;
    int temp;

    for (face = HEARTS; face <= CLUBS;  //stepping through the enum
        face = static_cast<suits>(face + 1)) {

        switch (numb)
        {
        case TWO: cout << "Two";
            break;
        case THREE: cout << "Three";
            break;
        case FOUR: cout << "Four";
            break;
        case FIVE: cout << "Five";
            break;
        case SIX: cout << "Six";
            break;
        case SEVEN: cout << "Seven";
            break;
        case EIGHT: cout << "Eight";
            break;
        case NINE: cout << "Nine";
            break;
        case TEN: cout << "Ten";
            break;
        case ACE: cout << "Ace";

        }

        cout << " of " << "";

        switch (face)
        {
        case HEARTS: cout << "Hearts";
            break;
        case DIAMONDS: cout << "Diamonds";
            break;
        case SPADES: cout << "Spades";
            break;
        case CLUBS: cout << "Clubs";

        }
    }

    /*int i = 0;
    for (suits suit = CLUBS; suit <= SPADES; suit = suits(suit + 1)) {
        for (ranks rank = ACE; rank <= KING; rank = ranks(rank + 1)) {
            card.deck[i]; suit = suit;
            card.deck[i]; rank = rank;
            i++;
        }
    }*/


    void createDeck(Cards[]);
    {

        for (face = HEARTS; face <= CLUBS;  //stepping through the enum
            face = static_cast<suits>(face + 1))
        {
            cout << HEARTS << endl;
            
        }


        for (numb; numb <= ACE;  //stepping through the enum
            numb = static_cast<ranks>(numb + 1))
        {
            cout << "The deck of cards: " << endl;
            cout << face << " of " << numb << endl;
        }

        

 /* void dealcard(Cards[]);
  {
    for (int i = 0; i < cards.Count; i++) 
    {
        int r = random.Next(i, cards.Count);
        var temp = cards[i];
        cards[i] = cards[r];
        cards[r] = temp;
    }
    for (int i = 0; i < 52; i++) 
    {
        deck.cards[i].print();
    }*/


        
  }
    return 0;
}



/*void printcard() 
{
    
}*/

Cards deck[52];
Cards card1, card2;
string cardName;
int cards;

Cards deal(deck[52]);
string winner(cards, cards);
 



/*void printDeck()
{

    for (int i = 0; i < 52; i++)
    {
        deck.cards[i].print();
    }
    
}*/









