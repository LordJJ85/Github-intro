//Ja'Saun Jones
//CIS 1202 502
//12-26-2020

#include <iostream>
#include <string>
#include <iomanip>
using namespace std;


struct Team

{
	string teamName;

	int totalWins;
	int totalLosses;

	int homeWins;
	int homeLosses;

	int awayWins;
	int awayLosses;
};

Team display;

struct WinLoss
{
	int wins;
	int losses;
};

WinLoss games;

//Function Prototypes
void displayWinLoss(WinLoss);
void displayTeam(Team);
int choice;  //Holds the menu choice;




int main()
{
	int Menu(int choice);
	void FindTeam(Team[], int);
	Team getTeam(Team);
	WinLoss getWinLoss(string location);


	void Menu();
	{


		do {

			cout << "\nMenu Choices\n\n"

				<< "1. Enter a new team" << endl

				<< "2. Display all teams" << endl

				<< "3. Display a particular team" << endl

				<< "4. Exit the program" << endl;

			cin >> choice;


			switch (choice)
			{
			case 1:
				Team getTeam(Team);
				break;
			case 2:
				void displayTeam(Team&);
				break;
			case 3:
				void FindTeam(Team[], int);
				break;

			case 4:return 0();
				break;

				//Validation for the menu
			default:
				if (choice < 1 || choice > 5)
				{
					cout << endl << "That is an invalid selection. Please enter a value  1-4:"
						<< endl;
					cin >> choice;
				}

			}
		} while (choice != 0 || choice > 4);


		cout << "\n";

		return 0;
	}


	WinLoss getWinLoss(string location);
	WinLoss games;
	{

		cout << "Enter Wins" << endl;
		cin >> games.wins;
		cout << endl;


		cout << "Enter Home" << endl;
		cin >> games.losses;
		cout << endl;


	}

	Team getTeam(Team);
	Team display;
	{

		string location;
		location = "Home";

		cout << "Enter Team Name" << endl;
		getline(cin, display.teamName);
		cout << endl;

		getWinLoss(location);
		location = "Away";

		getWinLoss(location);

		display.totalWins;
		display.totalLosses;

		display.totalWins = display.homeWins + display.awayWins;
		display.totalLosses = display.homeLosses + display.awayLosses;


	}

	void FindTeam(Team[], int);
	{
		cout << "Enter Team Name" << endl;
		getline(cin, display.teamName);
		cout << endl;
	}

	void displayWinLoss(WinLoss);
	{
		cout << "Home wins" + 1 << endl;

	}

	return 0;

}

