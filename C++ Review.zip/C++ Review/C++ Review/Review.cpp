//Ja'Saun Jones
//CIS 1201 502
//December 2, 2020

#include <iostream>
#include <fstream>
#include<string>
#include <numbers>
using namespace std;

int main()
{
	loadArrays;
	calculateValues;
	displayTable;


	const int ARRAY_SIZE = 20;
	int count;
	ofstream outputFile;

	void loadArrays(string[], int[], float[], int&);
	{
		//Open the file
		outputFile.open("inventory.txt");

		//Read data from the file into the array
		while (count < ARRAY_SIZE && inputFile >> numbers[count]) count++;

	}

	void calculateValues(int[], float[], float[], int);
	{
		int Quantity ,
			Cost ,
			 Total = 0; Value = (Quantity * Cost);

	}


	void displayTable(string product code, int quantity on hand, float cost, float total value, int);

	{
		cout << "Product Code" << setw(10) << product code << endl;
		cout << "Quantity On Hand" << setw(10) << quantity on hand << endl;
		cout << "Cost" << setw(10) << cost << endl;
		cout << "Total Value" << setw(10) << total value << endl;

	}

	// Close the file
	outputFile.close();

	//Display the data read


	return 0;
}