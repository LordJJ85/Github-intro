#include <string>
#include <iomanip>
#include <iostream>

using namespace std;

enum PublicationType { BOOK, MAGAZINE, NEWSPAPER, AUDIO, VIDEO };



int main()
{
    void storePublication(string itemTitle, string itemPublisher, double itemPrice, int itemYear, PublicationType itemType, int itemStock);
    void displayInfo();
    void checkOut();
    void checkIn();
    string getTitle();
    int getStock();
    void getPublicationInfo(Publication&);



}


void storePublication(string itemTitle, string itemPublisher, double itemPrice, int itemYear, PublicationType itemType, int itemStock)
{
    /*cout << "Enter book information: \nEnter book title: ";
    getline(cin, bookTitle);
    cout << "Enter author name: ";
    getline(cin, authorName);
    cout << "Enter book publisher: ";
    getline(cin, bookPublisher);
    cout << "Enter book ISBN: ";
    getline(cin, bookISBN,'\n');
    cout << "Enter book price: $";
    cin >> bookPrice;
    cout << "Enter year published: ";
    cin >> bookYear;
    cout << "Enter the number of books in stock: ";
    cin >> booksInStock;*/
    title = itemTitle;
    publisher = itemPublisher;
    type = itemType;
    price = itemPrice;
    year = itemYear;
    numInStock = itemStock;
}

void displayInfo()
{
    cout << "\n" << setw(17) << "Title: " << title << endl
        << setw(17) << "Publisher: " << publisher << endl
        << setw(17) << "Type " << type << endl
        << setw(18) << "Price: $" << price << endl
        << setw(17) << "Year: " << year << endl
        << setw(17) << "Number in stock: " << numInStock << endl;
}

void checkOut() {
    numInStock = numInStock - 1;
}

void checkIn() {
    numInStock = numInStock + 1;
}

string getTitle()
{
    return title;
}

int getStock()
{
    return numInStock;
}

void getPublicationInfo(&Publication)
{
    return numInStock;

}